
; x86-64 Assembly - NASM syntax (Linux)

global main
extern printf

section .data
    hello_msg   db "Hello C!", 10, 0
    args_msg    db "args passed through exe:", 10, 0
    no_args_msg db "no args passed", 10, 0
    arg_format  db "  %s", 10, 0

section .text

main:
    push rbp
    mov rbp, rsp
    push rbx
    push r12
    push r13

    ; Save arguments
    mov ebx, edi        ; argc
    mov r12, rsi        ; argv

    ; Call printHello()
    call printHello

    ; Check if argc > 1
    cmp ebx, 1
    jg has_args

    ; No arguments
    lea rdi, [rel no_args_msg]
    xor eax, eax
    call printf
    jmp finish

has_args:
    ; Print header
    lea rdi, [rel args_msg]
    xor eax, eax
    call printf

    ; i = 1
    mov r13d, 1

print_loop:
    ; Check i < argc
    cmp r13d, ebx
    jge finish

    ; printf("  %s\n", argv[i])
    lea rdi, [rel arg_format]
    mov rsi, [r12 + r13*8]
    xor eax, eax
    call printf

    inc r13d
    jmp print_loop

finish:
    ; Return 0
    xor eax, eax

    pop r13
    pop r12
    pop rbx
    pop rbp
    ret


printHello:
    push rbp
    mov rbp, rsp

    lea rdi, [rel hello_msg]
    xor eax, eax
    call printf

    pop rbp
    ret

# rune

Build & run tool designed for simple and predictable development in any major programming lang.

## Cli design

### 1. Cli args

```txt
usage (rune version): rune [input_path] [output_path | flag] [flags]
flags:
  --debug | --safe | --fast | --size              Set optimization level (default: --debug, when output_path provided: --fast)
  --target=[os]-[arch]-[abi?]                     Set target OS (default: current OS)

supported targets:
    linux-x86_64, linux-x86_64-musl, linux-aarch64, linux-aarch64-musl    Linux
    macos-x86_64, macos-aarch64                                           Darwin
    windows-x86_64, windows-aarch64                                       Windows
    browser                                           Wasm | HTML | CSS | JS | TS

  --run                   Run compiled program. evry arg passed after --run will be pass into running exe
  --info                  Print build/run info (useful for debugging)
  -h, --help              Show this help message

html only:
  --no-bundle             Only for html input, do not bundle favicon/css/js into html output
  --crossorgin            Add crossorgin attribute to script and link tags in html output (useful for cdn)

example usage:
  rune src/main.zig --run="my arg"
  rune src/main.rs
  rune src/main.c dist/main --fast
  rune src/main.cpp dist/main --debug
  rune src/server.js
  rune src/main.ts dist/main.js --size
  rune ./styles.css dist/styles.css --size
  rune src/index.html dist/index.html --size

supported extentions:
  .asm (native), .zig, .rs (native), .c, .cpp, .html, .css, .js, .ts, .jsx (node_modules), .tsx (node_modules), .py (run only)
```

## Project structure

#### src

- ./src/build - contains all building stuffs
- ./src/cli - parse command line for get config
- ./src/lib - cross-project consts and utilities
- ./src/run - run program

#### Other

- ./.cache (git ignored) - zig and rune cache
- ./dist (git ignored) - build output used in testing and releases for rune-web
- ./buid_dev.sh - build for testing
- ./build_release.sh - heplper to build release
- ./build_test.sh - test all build targets and runners

## Build code with rune

See `./build_test.sh`

## Suppoted

### Targets

| Os-Arch-Abi        | ASM | Zig | Rust              | C   | C++ | C#  | Java | Browser(Html/Css/JS/TS) | JSX//TSX | Py  |
| ------------------ | --- | --- | ----------------- | --- | --- | --- | ---- | ----------------------- | -------- | --- |
| linux-x86_64       | ⚠️  | ✅  | ⚠️                | ✅  | ✅  | ❌  | ❌   | ✅                      | ✅ (NM)  | ❌  |
| linux-x86_64-musl  | ⚠️  | ✅  | ⚠️ + linux-x86_64 | ✅  | ✅  | ❌  | ❌   | ✅                      | ✅ (NM)  | ❌  |
| linux-aarch64      | ⚠️  | ✅  | ❌                | ✅  | ✅  | ❌  | ❌   | ✅                      | ✅ (NM)  | ❌  |
| linux-aarch64-musl | ⚠️  | ✅  | ❌                | ✅  | ✅  | ❌  | ❌   | ✅                      | ✅ (NM)  | ❌  |
| macos-aarch64      | ⚠️  | ✅  | ⚠️                | ✅  | ✅  | ❌  | ❌   | ✅                      | ✅ (NM)  | ❌  |
| macos-x86_64       | ⚠️  | ✅  | ⚠️                | ✅  | ✅  | ❌  | ❌   | ✅                      | ✅ (NM)  | ❌  |
| windows-x86_64     | ⚠️  | ✅  | ⚠️                | ✅  | ✅  | ❌  | ❌   | ✅                      | ✅ (NM)  | ❌  |
| windows-aarch64    | ⚠️  | ✅  | ❌                | ✅  | ✅  | ❌  | ❌   | ✅                      | ✅ (NM)  | ❌  |
| android-aarch64    | ⚠️  | ✅  | ❌                | ❌  | ❌  | ❌  | ❌   | ❌                      | ❌       | ❌  |
| android-x86_64     | ⚠️  | ✅  | ❌                | ❌  | ❌  | ❌  | ❌   | ❌                      | ❌       | ❌  |
| browser (wasm)     | ⚠️  | ✅  | ❌                | ✅  | ✅  | ❌  | ❌   | ✅                      | ✅ (NM)  | ❌  |

⚠️ - native
NM - node_modules

### Code runners (Testing exe's)

| target                   | linux-x86_64 | linux-x86_64-musl | macos-aarch64 | macos-x86_64 | windows-x86_64 |
| ------------------------ | ------------ | ----------------- | ------------- | ------------ | -------------- |
| linux-x86_64             | ✅           | ❌                | ❌            | ❌           | ❌             |
| linux-x86_64-musl        | ❌           | ✅                | ❌            | ❌           | ❌             |
| linux-aarch64            | ❌           | ❌                | ❌            | ❌           | ❌             |
| linux-aarch64-musl       | ❌           | ❌                | ❌            | ❌           | ❌             |
| macos-aarch64            | ❌           | ❌                | ✅            | ❌           | ❌             |
| macos-x86_64             | ❌           | ❌                | ❌            | ✅           | ❌             |
| windows-x86_64           | ✅ (wine)    | ✅ (wine)         | ✅ (wine)     | ✅ (wine)    | ✅ (wine)      |
| windows-aarch64          | ❌ (wine)    | ❌ (wine)         | ❌ (wine)     | ❌ (wine)    | ❌ (wine)      |
| android-aarch64          | ❌           | ❌                | ❌            | ❌           | ❌             |
| android-x86_64           | ❌           | ❌                | ❌            | ❌           | ❌             |
| browser (wasm)           | ❌           | ❌                | ❌            | ❌           | ❌             |
| browser (Html/Css/JS/TS) | ✅           | ✅                | ✅            | ✅           | ✅             |

## TODO

- add support for: Rust (full), C#, Java, Python
- rune.json
  - Parse config
  - Run scripts
  - Dev mode
  - Build mode
- build target windows: create .pdb file only when opt == .debug
- add support for development on android
- add support for zig cInclude (-lc)
- add support for compiler custom flags via --raw flag
- make sth like ArgParser as wrapper for args parsing
- add --types flag for .ts
- add targets: android-[min_version], ios
- rune fmt .|.zig|.sh|... (format code)
